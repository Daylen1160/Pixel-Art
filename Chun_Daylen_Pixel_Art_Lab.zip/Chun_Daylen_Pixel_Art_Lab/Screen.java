import javax.swing.JPanel;
import java.awt.Graphics;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.*;
import javax.swing.*;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;


public class Screen extends JPanel implements MouseListener, ActionListener
{
	
	private Square[][] grid;
	private JButton resetButton;
	private JButton saveButton;
	
	//set r,g,b as instance variables
	int r = 255;
	int g = 255;
	int b = 255;
	
	public Screen()
	{
		setLayout(null);
		addMouseListener(this);
		
		grid = new Square[10][10];
		for (int i = 0; i < grid.length; i++)
		{
			for (int j = 0; j < grid[i].length; j++)
			{
				grid[i][j] = new Square(255, 255, 255);
				//0 0 0 black, 255 255 255 white
			}
		}
		
		//buton to reset grid
		resetButton = new JButton("Reset");
		resetButton.setBounds(450, 25, 100, 20);
		add(resetButton);
		resetButton.addActionListener(this);
		
		//button to save the image draw
		saveButton = new JButton("Save");
		saveButton.setBounds(450, 75, 100, 20);
		add(saveButton);
		saveButton.addActionListener(this);
		
		setFocusable(true);
	}
	
	public Dimension getPreferredSize()
	{
		return new Dimension(600,600);
		
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		//---draw the grid---///
		
		int x = 0;
		int y = 0;
		
		for (int i = 0; i < grid.length; i++)
		{
			for (int j = 0; j < grid[i].length; j++)
			{
				grid[i][j].drawMe(g, x, y);
				x+=40;//go to next square(column)
			}
			y+=40;//go to next line of squares(row
			x = 0;//reset the x to go back to the left side
		}
		
		//---draw a color palette---//
		
		//red
		g.setColor(Color.red);
		g.fillRect(50, 500, 50, 50);
		//green
		g.setColor(Color.green);
		g.fillRect(150, 500, 50, 50);
		//blue
		g.setColor(Color.blue);
		g.fillRect(250, 500, 50, 50);
		//white
		g.setColor(Color.white);
		g.fillRect(350, 500, 50, 50);
		//black
		g.setColor(Color.black);
		g.fillRect(450, 500, 50, 50);
	}
	
	public void mousePressed(MouseEvent e) 
 	{
		
		//---changing color---//
		
		//when clikck on color, set r,g,b instance variables to those values
		
		if (e.getX() >= 50 && e.getX() <= 100 && e.getY() >= 500 && e.getY() <= 550) 
		{
			System.out.println("COLOR: RED");
			r = 255;
			g = 0;
			b = 0;
		}
	
		else if (e.getX() >= 150 && e.getX() <= 200 && e.getY() >= 500 && e.getY() <= 550) 
		{
			System.out.println("COLOR: GREEN");
			r = 0;
			g = 255;
			b = 0;
		}
	
		else if (e.getX() >= 250 && e.getX() <= 300 && e.getY() >= 500 && e.getY() <= 550) 
		{
			System.out.println("COLOR: BLUE");
			r = 0;
			g = 0;
			b = 255;
		}
		
		else if (e.getX() >= 350 && e.getX() <= 400 && e.getY() >= 500 && e.getY() <= 550) 
		{
			System.out.println("COLOR: WHITE");
			r = 255;
			g = 255;
			b = 255;
		}
		
		else if (e.getX() >= 450 && e.getX() <= 500 && e.getY() >= 500 && e.getY() <= 550) 
		{
			System.out.println("COLOR: BLACK");
			r = 0;
			g = 0;
			b = 0;
		}
		
		//---drawing---//
		
		//get the location of the square in regards to the 2d array
		//change that square to color of instance variable
		
		//TO DO IT WITH MATH, YOU CAN USE 10 IF STATEMENTS TO SEE WHERE IT IS ON X AND
		//10 IF STATEMENTS FOR Y, THEN PUT THOSE TWO NUMBERS TOGETHER TO GET COORDINATE
		
		//represents location on grid
		
		if (e.getX() >= 0 && e.getX() <= 400 && e.getY() >= 0 && e.getY() <= 400)
		{
			System.out.println("Square clicked!");
			int x = 0;
			int y = 0;
			for (int i = 0; i <= 360; i+=40)//i represents x on grid(column)
			{
				for (int j = 0; j <= 360; j+=40)//j represents y on grid(row)
				{
					if (e.getX() >= i && e.getX() <= i + 40 && e.getY() >= j && e.getY() <= j + 40)
					{
						x = j / 40;
						y = i / 40;
					}
				}
			}
	
			//square in grid change color
			grid[x][y].changeColor(r, g, b);
			repaint();
		}
		
 	}
 	
 	public void mouseReleased(MouseEvent e) {}

    public void mouseEntered(MouseEvent e) {}

    public void mouseExited(MouseEvent e) {}

    public void mouseClicked(MouseEvent e) {}
    
    public void actionPerformed(ActionEvent e)
	{
		//reset grid
		if (e.getSource() == resetButton)
		{
			System.out.println("resetting...");
			for (int i = 0; i < grid.length; i++)
			{
				for (int j = 0; j < grid[i].length; j++)
				{
					grid[i][j].changeColor(255, 255, 255);
				}
			}
		}
		
		//save image
		
		if (e.getSource() == saveButton)
		{
			System.out.println("Image saved!");
			saveImage("save", "png");
			repaint();
		}
	}
	
	public void saveImage(String name,String type) 
	{
		BufferedImage image = new BufferedImage(getWidth(),getHeight(), BufferedImage.TYPE_INT_RGB);
		Graphics2D g2 = image.createGraphics();
		paint(g2);
		try
		{
			ImageIO.write(image, type, new File(name+"."+type));
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	

}