import java.awt.Graphics;
import java.awt.Color;

public class Square
{
	
	private int red;
	private int green;
	private int blue;
	
	public Square(int r, int g, int b)
	{
		red = r;
		green = g;
		blue = b;
	}
	
	public void drawMe(Graphics g, int x, int y)
	{
		g.setColor(new Color(red, green, blue));
		g.fillRect(x, y, 40, 40);
		g.setColor(Color.black);
		g.drawRect(x, y, 40, 40);
	}
	
	//---create method called changeColor(int r, int g, int b) and will update the color---//
	public void changeColor(int r, int g, int b)
	{
		//set color to arguments passed in
		red = r;
		green = g;
		blue = b;
	}
}